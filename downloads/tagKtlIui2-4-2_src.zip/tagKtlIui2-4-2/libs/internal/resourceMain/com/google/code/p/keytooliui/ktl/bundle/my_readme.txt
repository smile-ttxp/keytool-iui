6:55 PM 12/2/2005
####

TMEntryKprSel.properties
TMEntryTcrSel.properties
==> same contents!

TMEntryKprShowAll.properties
TMEntryTcrShowAll.properties
==> same contents!