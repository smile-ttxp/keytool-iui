package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESVerify24 extends BESVerifyAbs
{
    // --------------------
    // FINAL STATIC PRIVATE
    
    final static private String _f_s_strImage = "hammer24.gif"; // tempo
    
    // ------
    // PUBLIC
        
    public BESVerify24(java.awt.event.ActionListener alr)
    {
        super(alr, BESVerify24._f_s_strImage);        
    }
}
