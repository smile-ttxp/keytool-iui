package com.google.code.p.keytooliui.ktl.swing.button;

/*
 *JOOST requirements: view XML file (button) in directory to be jarred
 */

final public class BESMore16 extends BESMoreAbs
{
    // -------------------
    // FINAL STATIC PUBLIC
    
    final static public String f_s_strImage = "about16.gif";
    
    // ------
    // PUBLIC
        
    public BESMore16(java.awt.event.ActionListener alr)
    {
        super(alr, BESMore16.f_s_strImage, 16);        
    }
}
