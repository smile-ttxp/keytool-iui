package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESTool16 extends BESToolAbs
{
    // -------------------
    // FINAL STATIC PUBLIC
    
    final static public String f_s_strImage = "hammer16.gif";
    
    // ------
    // PUBLIC
        
    public BESTool16(java.awt.event.ActionListener alr)
    {
        super(alr, BESTool16.f_s_strImage);        
    }
}