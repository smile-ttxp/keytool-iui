package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESView16 extends BESViewAbs
{
    // -------------------
    // FINAL STATIC PUBLIC
    
    final static public String f_s_strImage = "find16.gif";
    
    // ------
    // PUBLIC
        
    public BESView16(java.awt.event.ActionListener alr)
    {
        super(alr, BESView16.f_s_strImage, 16);        
    }
}