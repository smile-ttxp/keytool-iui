package com.google.code.p.keytooliui.ktl.swing.internalframe;

import java.awt.Frame;
import com.google.code.p.keytooliui.ktl.swing.panel.*;


public class IFKstOpenCrKprV3CEc extends IFAbs
{
    public IFKstOpenCrKprV3CEc(Frame frmParent, String strTitleAppli)
    {
        super();
        
        super._pnl_ = new PTabUICmdKtlKstOpenCrKprV3CEc(frmParent, strTitleAppli);
        setTitle(PTabUICmdKtlKstOpenCrKprV3CEc.STR_TITLETASK);
    }

}
