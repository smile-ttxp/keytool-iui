package com.google.code.p.keytooliui.ktl.swing.button;

/*

 */

final public class BESFolderClose16 extends BESFolderCloseAbs
{
    // -------------------
    // FINAL STATIC PUBLIC
    
    final static public String f_s_strImage = "folderclose16.gif";
    
    // ------
    // PUBLIC
        
    public BESFolderClose16(java.awt.event.ActionListener alr)
    {
        super(alr, BESFolderClose16.f_s_strImage, 16);        
    }
}


