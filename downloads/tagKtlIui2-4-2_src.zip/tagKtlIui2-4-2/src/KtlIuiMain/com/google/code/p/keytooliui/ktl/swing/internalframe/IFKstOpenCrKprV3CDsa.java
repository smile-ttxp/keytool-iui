package com.google.code.p.keytooliui.ktl.swing.internalframe;

import java.awt.Frame;
import com.google.code.p.keytooliui.ktl.swing.panel.*;


public class IFKstOpenCrKprV3CDsa extends IFAbs
{
    public IFKstOpenCrKprV3CDsa(Frame frmParent, String strTitleAppli)
    {
        super();
        
        super._pnl_ = new PTabUICmdKtlKstOpenCrKprV3CDsa(frmParent, strTitleAppli);
        setTitle(PTabUICmdKtlKstOpenCrKprV3CDsa.STR_TITLETASK);
    }

}
