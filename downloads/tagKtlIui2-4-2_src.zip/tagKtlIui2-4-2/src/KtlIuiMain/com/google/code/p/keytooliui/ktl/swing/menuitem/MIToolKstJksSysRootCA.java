package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/

import com.google.code.p.keytooliui.shared.lang.*;
import com.google.code.p.keytooliui.shared.swing.menuitem.*;

import java.awt.event.*;

final public class MIToolKstJksSysRootCA extends MIKstJksCrtAbs
{
    // ------
    // PUBLIC
    
    public MIToolKstJksSysRootCA(ActionListener actListenerParent)
    {
        super(
            MIViewKstJksSysRootCA.s_strPrefix,
            actListenerParent
            );
    }
}
