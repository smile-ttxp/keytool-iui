package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/

import com.google.code.p.keytooliui.shared.lang.*;
import com.google.code.p.keytooliui.shared.swing.menuitem.*;

import java.awt.event.*;

final public class MIViewCrtPkcs7 extends MIAbstract
{
    // --------------
    // STATIC PRIVATE
    
    static public String STR_TEXT = null;
    
    // ------------------
    // STATIC INITIALIZER

    static
    {    
        String strBundleFileShort =
            com.google.code.p.keytooliui.ktl.AppMainUIAbs.f_s_strBundleDir +
            ".MIViewCrtPkcs7" // class name
            ;

        String strWhere = "com.google.code.p.keytooliui.ktl.swing.menuitem.MIViewCrtPkcs7";
        
        try
        {
            java.util.ResourceBundle rbeResources = java.util.ResourceBundle.getBundle(strBundleFileShort, 
                java.util.Locale.getDefault());
                
            MIViewCrtPkcs7.STR_TEXT = rbeResources.getString("text");
        }
        
        catch (java.util.MissingResourceException excMissingResource)
        {
            excMissingResource.printStackTrace();
            MySystem.s_printOutExit(strWhere, "excMissingResource caught");
        }
    }
    
    // ------
    // PUBLIC
    
    public MIViewCrtPkcs7(ActionListener actListenerParent)
    {
        super(
            MIViewCrtPkcs7.STR_TEXT,
            actListenerParent
            );
    }
}