package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/



import java.awt.event.*;

final public class MISelTabCreateKprV3CRsa extends MISelTabCreateKprAbs
{    
    // ------
    // PUBLIC
    
    public MISelTabCreateKprV3CRsa(
        ActionListener actListenerParent
        )
    {
        super(
            "RSA private key, with vers. #3 cert.", 
            actListenerParent);
    }
}

