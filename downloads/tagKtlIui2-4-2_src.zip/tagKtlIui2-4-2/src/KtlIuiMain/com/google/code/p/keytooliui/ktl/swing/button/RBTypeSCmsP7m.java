package com.google.code.p.keytooliui.ktl.swing.button;
 

import java.awt.event.*;
 
final public class RBTypeSCmsP7m extends RBTypeSigAbs
{    
    // ------
    // PUBLIC
    
    public RBTypeSCmsP7m(
        boolean blnIsEnabled,
        ItemListener itmListenerParent)
    {
        super(
            blnIsEnabled,
            itmListenerParent,
            com.google.code.p.keytooliui.ktl.util.jarsigner.KTLAbs.f_s_strFormatFileSCmsP7m,
            com.google.code.p.keytooliui.ktl.io.S_FileExtensionUI.f_s_strsSCmsP7m
            );
    }
}

