package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/



import java.awt.event.*;

final public class MISelTabCreateKprV3CEc extends MISelTabCreateKprAbs
{    
    // ------
    // PUBLIC
    
    public MISelTabCreateKprV3CEc(
        ActionListener actListenerParent
        )
    {
        super(
            "EC private key, with vers. #3 cert.", 
            actListenerParent);
    }
}


