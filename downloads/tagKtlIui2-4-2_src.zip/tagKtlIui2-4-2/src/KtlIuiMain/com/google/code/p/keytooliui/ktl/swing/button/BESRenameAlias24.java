package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESRenameAlias24 extends BESRenameAliasAbs
{
    // --------------------
    // FINAL STATIC PRIVATE
    
    final static private String _f_s_strImage = "about24.gif";
    
    // ------
    // PUBLIC
        
    public BESRenameAlias24(java.awt.event.ActionListener alr)
    {
        super(alr, BESRenameAlias24._f_s_strImage, 24);        
    }
}