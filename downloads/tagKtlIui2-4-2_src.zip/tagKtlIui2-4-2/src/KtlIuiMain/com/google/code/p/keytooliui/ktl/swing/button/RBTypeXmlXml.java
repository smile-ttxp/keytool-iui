package com.google.code.p.keytooliui.ktl.swing.button;
 

import java.awt.event.*;
 
final public class RBTypeXmlXml extends RBTypeXmlAbs
{    
    // ------
    // PUBLIC
    
    public RBTypeXmlXml(
        boolean blnIsEnabled,
        ItemListener itmListenerParent)
    {
        super(
            blnIsEnabled,
            itmListenerParent,
            com.google.code.p.keytooliui.ktl.util.jarsigner.KTLAbs.f_s_strFormatFileXmlXml,
            com.google.code.p.keytooliui.ktl.io.S_FileExtensionUI.f_s_strsXmlXml
            );
    }
}

