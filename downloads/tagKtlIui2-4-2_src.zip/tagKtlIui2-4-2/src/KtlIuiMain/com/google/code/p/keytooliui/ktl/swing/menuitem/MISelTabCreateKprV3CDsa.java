package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/



import java.awt.event.*;

final public class MISelTabCreateKprV3CDsa extends MISelTabCreateKprAbs
{    
    // ------
    // PUBLIC
    
    public MISelTabCreateKprV3CDsa(
        ActionListener actListenerParent
        )
    {
        super(
            "DSA private key, with vers. #3 cert.", 
            actListenerParent);
    }
}
