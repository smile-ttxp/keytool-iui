package com.google.code.p.keytooliui.ktl.swing.menuitem;

/**
**/


import java.awt.event.*;

final public class MISelTabCreateKprEc extends MISelTabCreateKprAbs
{    
    // ------
    // PUBLIC
    
    public MISelTabCreateKprEc(
        ActionListener actListenerParent
        )
    {
        super(
            "EC private key, with vers. #1 cert.", 
            actListenerParent);
    }
}