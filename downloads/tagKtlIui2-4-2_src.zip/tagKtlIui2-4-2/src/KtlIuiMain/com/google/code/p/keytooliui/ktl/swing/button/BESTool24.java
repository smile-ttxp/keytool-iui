package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESTool24 extends BESToolAbs
{
    // --------------------
    // FINAL STATIC PRIVATE
    
    final static private String _f_s_strImage = "hammer24.gif";
    
    // ------
    // PUBLIC
        
    public BESTool24(java.awt.event.ActionListener alr)
    {
        super(alr, BESTool24._f_s_strImage);        
    }
}