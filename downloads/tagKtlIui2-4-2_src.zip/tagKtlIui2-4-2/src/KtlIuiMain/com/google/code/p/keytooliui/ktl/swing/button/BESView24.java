package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESView24 extends BESViewAbs
{
    // --------------------
    // FINAL STATIC PRIVATE
    
    final static private String _f_s_strImage = "find24.gif";
    
    // ------
    // PUBLIC
        
    public BESView24(java.awt.event.ActionListener alr)
    {
        super(alr, BESView24._f_s_strImage, 24);        
    }
}