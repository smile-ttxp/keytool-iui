package com.google.code.p.keytooliui.ktl.swing.button;


final public class BESSign24 extends BESSignAbs
{
    // --------------------
    // FINAL STATIC PRIVATE
    
    final static private String _f_s_strImage = "hammer24.gif"; // tempo
    
    // ------
    // PUBLIC
        
    public BESSign24(java.awt.event.ActionListener alr)
    {
        super(alr, BESSign24._f_s_strImage);        
    }
}
