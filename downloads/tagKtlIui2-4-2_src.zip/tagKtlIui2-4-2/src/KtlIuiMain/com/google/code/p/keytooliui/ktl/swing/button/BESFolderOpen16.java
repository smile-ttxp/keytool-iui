package com.google.code.p.keytooliui.ktl.swing.button;

/*

 */

final public class BESFolderOpen16 extends BESFolderOpenAbs
{
    // -------------------
    // FINAL STATIC PUBLIC
    
    final static public String f_s_strImage = "folderopen16.gif";
    
    // ------
    // PUBLIC
        
    public BESFolderOpen16(java.awt.event.ActionListener alr)
    {
        super(alr, BESFolderOpen16.f_s_strImage, 16);        
    }
}

