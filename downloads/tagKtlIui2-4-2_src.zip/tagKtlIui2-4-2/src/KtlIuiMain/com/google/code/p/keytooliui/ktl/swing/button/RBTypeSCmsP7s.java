package com.google.code.p.keytooliui.ktl.swing.button;
 

import java.awt.event.*;
 
final public class RBTypeSCmsP7s extends RBTypeSigAbs
{    
    // ------
    // PUBLIC
    
    public RBTypeSCmsP7s(
        boolean blnIsEnabled,
        ItemListener itmListenerParent)
    {
        super(
            blnIsEnabled,
            itmListenerParent,
            com.google.code.p.keytooliui.ktl.util.jarsigner.KTLAbs.f_s_strFormatFileSCmsP7s,
            com.google.code.p.keytooliui.ktl.io.S_FileExtensionUI.f_s_strsSCmsP7s
            );
    }
}


