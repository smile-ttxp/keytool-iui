/*
 *
 * Copyright (c) 2001-2002 XLReader Project.
 * All Rights Reserved.
 * http://www.xlreader.com
 *
 * This software is the confidential and proprietary information of XL-Reader Project.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of XL-Reader Project's license agreement.
 *
 * THE SOFTWARE IS PROVIDED AND LICENSED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * LICENSE FOR THE SOFTWARE DOES NOT INCLUDE ANY CONSIDERATION FOR ASSUMPTION OF RISK
 * BY XL-READER PROJECT, AND XL-READER PROJECT DISCLAIMS ANY AND ALL LIABILITY FOR INCIDENTAL
 * OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF OR INABILITY
 * TO USE THE SOFTWARE, EVEN IF XL-READER PROJECT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
 *
 */


package com.xlreader.shared.help.impl;

/**

    usage:, in HTML file, add the object tag:
    
    <OBJECT classid="java:com.xlreader.shared.help.impl.JHBrowserViewer">
    <param name="viewerActivator" value="javax.help.LinkLabel">
    <param name="text" value="Yahoo!">
    <param name="content" value="http://www.yahoo.com">
</OBJECT>  


**/

import com.xlreader.shared.lang.*;

import com.sun.java.help.impl.*;

import javax.swing.*;

import java.awt.*;

final public class JHBrowserViewer extends JH2Abs
{
    // --------------
    // STATIC PRIVATE
    
    static private String _s_strDialogFailed = null;
    
    /**static private JFrame _s_getFrameOwnerHelpSet(Component cmp)
    {
        while (cmp != null)
	    {        
	        if (cmp instanceof JFrame) 
	            return (JFrame) cmp;
        	        
	        cmp = cmp.getParent();
	    }
	            
        return null;
    }**/
    
    // ------------------
    // STATIC INITIALIZER

    static
    {
        java.util.ResourceBundle rbeResources;
    
        final String f_strBundleFileShort =
            com.xlreader.shared.Shared.f_s_strBundleDir +
            ".JHBrowserViewer" // class name
            ;

        final String f_strWhere = "com.xlreader.shared.help.impl.JHBrowserViewer";
        
        try
        {
            rbeResources = java.util.ResourceBundle.getBundle(f_strBundleFileShort, 
                java.util.Locale.getDefault());
                
            _s_strDialogFailed = rbeResources.getString("dialogFailed");
        }
        
        catch (java.util.MissingResourceException excMissingResource)
        {
            excMissingResource.printStackTrace();
            MySystem.s_printOutExit(f_strWhere, "excMissingResource caught");
        }
    }
    
    // ------
    // PUBLIC
    
    /**
        overwriting superclass's method
    **/
    public void actionPerformed(java.awt.event.ActionEvent evtAction)
    {
        String strMethod = "actionPerformed(evtAction)";
  
        if (this._cmpFrameOwnerHelpSet == null)
        {
            JFrame frm = JH2Abs._s_getFrameOwnerHelpSet_(this);
            
            if (frm == null)
                MySystem.s_printOutExit(this, strMethod, "nil frm");
                
            this._cmpFrameOwnerHelpSet = (Component) frm;
            
            if (frm.getTitle() == null)
                this._strTitleHelpSet = "JavaHelp";
            else
                this._strTitleHelpSet = frm.getTitle();
        }
                
                
        if (com.xlreader.shared.io.S_ToBrowserDefault.s_displayURL(
            this._cmpFrameOwnerHelpSet, this._strTitleHelpSet, getContent()))
            return;
            
        // error
        MySystem.s_printOutError(this, strMethod, "failed, getContent()=" + getContent());
        
        com.xlreader.shared.awt.MyToolkit.s_beep();	
       
        String strBody = 
            _s_strDialogFailed +
            "\n" +
            getContent();
        
        com.xlreader.shared.swing.optionpane.OPAbstract.s_showDialogError(
            this._cmpFrameOwnerHelpSet, 
            this._strTitleHelpSet, 
            strBody);
        
    }
    
    public JHBrowserViewer()
    {
        //super();
    }
    
    // -------
    // PRIVATE
    
    private java.awt.Component _cmpFrameOwnerHelpSet = null; 
    private String _strTitleHelpSet = null;
}