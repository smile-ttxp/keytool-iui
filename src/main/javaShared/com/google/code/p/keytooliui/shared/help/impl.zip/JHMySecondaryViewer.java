/*
 *
 * Copyright (c) 2001-2003 XLReader Project.
 * All Rights Reserved.
 * http://www.xlreader.com
 *
 * This software is the confidential and proprietary information of XL-Reader Project.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of XL-Reader Project's license agreement.
 *
 * THE SOFTWARE IS PROVIDED AND LICENSED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * LICENSE FOR THE SOFTWARE DOES NOT INCLUDE ANY CONSIDERATION FOR ASSUMPTION OF RISK
 * BY XL-READER PROJECT, AND XL-READER PROJECT DISCLAIMS ANY AND ALL LIABILITY FOR INCIDENTAL
 * OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF OR INABILITY
 * TO USE THE SOFTWARE, EVEN IF XL-READER PROJECT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
 *
 */

package com.xlreader.shared.help.impl;

/**
    !!!!
    duplication of JHSecondaryViewer: overwriting all public & protected superclass's method
    !!!!
    
    
    ####
    January 10, 2002
    #### 
   
    adding code: 
    if frame's window [width-height] upper than user's screen [width-height],
      assign [width-height] to fit user's screen [width-height]


    ####
    January 8, 20002
    ####
    
    
    MODIFS in order to:
    
    1) fix up memory leaks
       EG: succession of open/close secondary window: memory size increases, never release, till appli hangs up
    
    2) fix up tbrl: if secondary windows is iconified, 
       then clicking on the links has no effects (secondary win remains iconified)

    3) adding code that allows to assign same icon has the one in frameOwner
    
    4) modif code to remove deprecated call to 
       FontMetrics Toolkit.getFontMetrics(Font font)
    
    
       
    IMPORTANT:
    
    Just tested this for use as a secondary window, NOT as a pop window
    . Windows 2000
    . JVM 1.3.1
    . JH 1.1.2
**/


import com.xlreader.shared.lang.*;

import com.sun.java.help.impl.*;


import javax.help.*;
import javax.help.Map.*;

import javax.swing.text.*;
import javax.swing.*;
import javax.swing.text.html.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.net.*;

final public class JHMySecondaryViewer extends JH2Abs
{
    // ------------
    // FINAL STATIC
    
    final static private String _f_s_strButtonPropertyPrefix = "Button" + ".";
    final static private String _f_s_strEditorPropertyPrefix = "EditorPane" + ".";
    
    final static private Cursor _f_s_CrsHandCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
    
    final static private int _f_s_intSizeMin = 200;
    
    // --------------
    // STATIC PRIVATE
    
    static private MySecondaryView _s_popupView;
    static private Hashtable _s_hstSecondaryWins = new Hashtable();
    static private Component _s_container;
    
    /*static private JFrame _s_getFrameOwnerHelpSet(Component cmp)
    {
        while (cmp != null)
	    {        
	        if (cmp instanceof JFrame) 
	            return (JFrame) cmp;
        	        
	        cmp = cmp.getParent();
	    }
	            
        return null;
    }*/
    
    // ------
    // PUBLIC

    /**
     * Create a secondaryviewer. By default the viewer creates a button with
     * the text of ">"
     */
    public JHMySecondaryViewer()
    {
        String strMethod = "JHMySecondaryViewer()";
        MySystem.s_printOutTrace(this, strMethod, "...");
        
        
	    //super();
	    setText(">");
	    setMargin(new Insets(0,0,0,0));
	    _createLinkButton();
	    addActionListener(this);
	    _crsOrigCursor = getCursor();
	    
	    addMouseListener(new MouseListener() 
	    {
	        public void mouseClicked(MouseEvent e) 
	        {
	        }

	        public void mouseEntered(MouseEvent e) 
	        {
		        setCursor(_f_s_CrsHandCursor);
	        }

	        public void mouseExited(MouseEvent e) 
	        {
		        setCursor(_crsOrigCursor);
	        }

	        public void mousePressed(MouseEvent e) 
	        {
	        }

	        public void mouseReleased(MouseEvent e) 
	        {
	        }
	    });
    }

    /**
     * Sets data optained from the View
     */
    public void setViewData(View v) 
    {
        String strMethod = "setViewData(v)";
        
        MySystem.s_printOutTrace(this, strMethod, "#### ... ####");
                
        if (v == null)
            MySystem.s_printOutExit(this, strMethod, "nil v");
        
        
        
	    _myView = v;
	    _doc = (HTMLDocument) _myView.getDocument();
	    _base = _doc.getBase();

	    // Set the current font information in the local text attributes
	    Font font = getFont();
	    _textAttribs = new SimpleAttributeSet();
	    _textAttribs.removeAttribute(StyleConstants.FontSize);
	    _textAttribs.removeAttribute(StyleConstants.Bold);
	    _textAttribs.removeAttribute(StyleConstants.Italic);
	    _textAttribs.addAttribute(StyleConstants.FontFamily,
				    font.getName());
	    _textAttribs.addAttribute(StyleConstants.FontSize,
				    new Integer(font.getSize()));
	    _textAttribs.addAttribute(StyleConstants.Bold,
				    new Boolean(font.isBold()));
	    _textAttribs.addAttribute(StyleConstants.Italic,
				    new Boolean(font.isItalic()));


	    // Loop through and find the JHelpContentViewer
	    Component c = _s_container = (Component) _myView.getContainer();
	    while (c != null)
	    {
	        if (c instanceof JHelpContentViewer) {
		    break;
	        }
	        c = c.getParent();
	    }

	    // Get the helpset if there was JHelpContentViewer
	    if (c !=null) {
	        TextHelpModel thm = ((JHelpContentViewer)c).getModel();
	        if (thm != null) {
		    _hs = thm.getHelpSet();
	        }
	    }
    }

   

    class MySecondaryView 
    {
        // ------
        // public
        
	    public JFrame frame;
	    public JPopupMenu popup;
	    public JEditorPane editor;
	    public JHelpContentViewer jheditor;
	    public String name;

	    public MySecondaryView(JFrame frame, JPopupMenu popup, 
	        JEditorPane editor, 
			JHelpContentViewer jheditor,
			String name) 
        {
	        this.frame = frame;
	        this.popup = popup;
	        this.editor = editor;
	        this.jheditor = jheditor;
	        this.name = name;
	    }
	    
	    public boolean init() { return true; }
	    
	    public void destroy()
	    {
	        if (this.frame != null)
	        {
	            this.frame.dispose();
	            this.frame = null;
	        }
	        
	        if (this.popup != null)
	        {
	            this.popup = null;
	        }
	        
	        if (this.editor != null)
	        {
	            this.editor = null;
	        }
	        
	        if (this.jheditor != null)
	        {
	            this.jheditor = null;
	        }
	        
	        
	        if (this.name != null)
	        {
	            this.name = null;
	        }
	    }

    }

   
    /**
     * Set the content for the secondary viewer
     * @param content a valid URL
     */
    public void setContent(String strContent)
    {
        String strMethod = "setContent(strContent)";
                
        if (strContent == null)
            MySystem.s_printOutExit(this, strMethod, "nil strContent");
        
        
        this.content = strContent;
	    ident = null;
    }

    /**
     * Returns the content of the secondary viewer
     */
    public String getContent() 
    {
        String strMethod = "getContent()";
                         
         // return the URL of the ident if set
	    if (ident != null)
	    {
	        Map map = _hs.getCombinedMap();
	        
	        try 
	        {
	            URL url = map.getURLFromID(ident);
	            return (url.toExternalForm());
	        } 
	        
	        catch (Exception exc) 
	        {
	            exc.printStackTrace();
	            MySystem.s_printOutWarning(this, strMethod, "exc caught, igonoring");
	        }
	    
	    }

	    // just return the content even if ""
	    return content;
    }

    /**
     * Set the ID for content in the secondary viewer
     * @param content a valid URL
     */
    public void setId(String strID)
    {
        String strMethod = "setId(strID)";
                
        if (strID == null)
            MySystem.s_printOutExit(this, strMethod, "nil strID");
            
        ident = Map.ID.create(strID, _hs);
	    content = "";
    }

    /**
     * Returns the ID of the secondary viewer
     */
    public String getId()
    {
        String strMethod = "getId()";
                
        if (ident == null)
            MySystem.s_printOutExit(this, strMethod, "nil ident");
        
        return ident.id;
    }

    /**
     * Sets the viewer name to display the content in.
     * Viewer is only valid for ViewerStyle "SecondaryWindow"
     */
    public void setViewerName(String strName)
    {
        String strMethod = "setViewerName(strName)";
                
        if (strName == null)
            MySystem.s_printOutExit(this, strMethod, "nil strName");
        
        viewerName = strName;
    }

    /**
     * Returns the viewer name
     */
    public String getViewerName()
    {
        return viewerName;
    }

    /**
     * Sets the viewer activator.
     * Valid activators are
     * <ul>
     * <li>javax.help.LinkButton
     * <li>javax.help.LinkLabel
     * </ul>
     * The new activatory type will be used the next time a view is displayed.
     */
    public void setViewerActivator(String strActivator) 
    {
        String strMethod = "setViewerActivator(strActivator)";
                
        if (strActivator == null)
            MySystem.s_printOutExit(this, strMethod, "nil strActivator");
        
        if (strActivator.toLowerCase().compareTo(LINK_BUTTON.toLowerCase()) == 0 && viewerActivator != 0) 
        {
	        viewerActivator = 0;
	        _createLinkButton();
	    } 
	    
	    else if (strActivator.toLowerCase().compareTo(LINK_LABEL.toLowerCase()) == 0 && viewerActivator != 1) 
	    {
	        viewerActivator = 1;
	        _createLinkLabel();
	    }
	    
	    /**else
	    {
	        MySystem.s_printOutTrace(this, strMethod, 
	            "uncaught case, ignoring, strActivator=" + 
	            strActivator + 
	            ", viewerActivator=" + 
	            viewerActivator);
	    }**/
    }

    /**
     * Returns the viewer activator
     */
    public String getViewerActivator() 
    {
        
        // OK can redirect to subclass
	    return super.getViewerActivator();
    }

    
	
   
	
    /**
     * Sets the viewer style. There are two valid viewer styles:
     * <ul>
     * <li>javax.help.SecondaryWindow
     * <li>javax.help.Popup
     * <ul>
     * <p>
     * Viewer style is updated the next time the viewer is made visible
     * @param style a valid ViewerStyle
     */
    public void setViewerStyle(String strStyle)
    {
        String strMethod = "setViewerStyle(strStyle)";
                
        if (strStyle == null)
            MySystem.s_printOutExit(this, strMethod, "nil strStyle");
        
        
	    if (strStyle.compareTo(SECONDARY_WINDOW) == 0)
	    {
	        viewerStyle = 0;
	    } 
	    
	    else if (strStyle.compareTo(POPUP) == 0) 
	    {
	        viewerStyle = 1;
	    }
	    
	    else
	        MySystem.s_printOutExit(this, strMethod, ".uncaught strStyle, strStyle=" + strStyle);
    }

    /**
     * Returns the current ViewerStyle
     */
    public String getViewerStyle()
    {

	    switch (viewerStyle) 
	    {
	        case 0:
	            return SECONDARY_WINDOW;
	        case 1:
	            return POPUP;
	    }
	    
	    return "unknownStyle";
    }

    /**
     * Sets the viewer's location to display the content in.
     * Location is relative to the screen or a modal dialog box
     * The String must be in the form of "x,y". If no viewer location
     * is established the default is 0,0 for secondary windows. Location
     * is ignored for popups.
     * @see getViewerLocation
     */
    public void setViewerLocation(String strLocation)
    {
        String strMethod = "setViewerLocation(strLocation)";
        
        
        if (strLocation == null)
            MySystem.s_printOutExit(this, strMethod, "nil strLocation");
        
	    int comma = strLocation.indexOf(",");
	    
	    if (comma != -1) 
	    {
	        String x = strLocation.substring(0,comma).trim();
	        String y = strLocation.substring(comma+1).trim();
	        
	        if (x != null && y != null) 
	        {
		        viewerX = Integer.parseInt(x);
		        viewerY = Integer.parseInt(y);
	        }
	    }
	    
	    else
	    {
	        MySystem.s_printOutWarning(this, strMethod, "comma == -1, strLocation=" + strLocation + ", ignoring");
        }
    }

    /**
     * Returns the viewer Location. Location is relative to the screen or
     * a modal dialog box. The form of the location is "x,y". 
     * The default location is 0,0.
     * @see setViewerLocation
     */
    public String getViewerLocation()
    {
	    MySecondaryView view;
	    
	    String retval = Integer.toString(viewerX) + "," +
	        Integer.toString(viewerY);

	    // try to return the actual viewer locations if it exists
	    switch (viewerStyle) 
	    {
	        case 0:
	            view = (MySecondaryView)_s_hstSecondaryWins.get(viewerName);
	            
	            if (view != null) 
	            {
		            retval = Integer.toString(view.frame.getLocation().x) + "," +
		                Integer.toString(view.frame.getLocation().y);
	            }
	            
	            break;
	        case 1:
	            // ignored in popups
	            break;
	    }
	    
	    return retval;
    }

    /**
     * Sets the viewer's size to display the content in.
     * The String must be in the form of "width,heigt". 
     * If no size is set the default is _f_s_intSizeMin,_f_s_intSizeMin.
     * @see getViewerSize
     */
    public void setViewerSize(String strSize)
    {
        String strMethod = "setViewerSize(strSize)";
        
        
        if (strSize == null)
            MySystem.s_printOutExit(this, strMethod, "nil strSize");
            
        MySystem.s_printOutTrace(this, strMethod, "strSize=" + strSize);
        
	    
	    int comma = strSize.indexOf(",");
	    
	    if (comma == -1)
	    {
	        MySystem.s_printOutWarning(this, strMethod, "comma == -1, strSize=" + strSize + ", ignoring");
	        return;
	    }
	    
	    // ----
	    
	    int intW = -1;
	    int intH = -1;
	    
	    try
	    {
	        String width = strSize.substring(0,comma).trim();
	        String height = strSize.substring(comma+1).trim();
    	        
	        if (width != null && height != null) 
	        {
		        intW = Integer.parseInt(width);
		        intH = Integer.parseInt(height);
	        }
	    }
	        
	    catch(Exception exc) // author error
	    {
	        exc.printStackTrace();
	        MySystem.s_printOutWarning(this, strMethod, "exc caught, strSize=" + strSize + ", ignoring");
	        return;
	    }
	   
	    // got size
	    
	    java.awt.Dimension dimScreen = null;
        
        try
        {
            java.awt.Toolkit tkt = java.awt.Toolkit.getDefaultToolkit();
            dimScreen = tkt.getScreenSize();
        }
        
        catch(java.awt.AWTError errAWT)
        {
            errAWT.printStackTrace();
            MySystem.s_printOutExit(this, strMethod, "err caught");  
        }
        
        MySystem.s_printOutTrace(this, strMethod, "dimScreen=" + dimScreen);
        
        java.awt.Insets ins = getInsets();
        
        
        int intWAllowed = dimScreen.width - ins.left - ins.right;
        int intHAllowed = dimScreen.height - ins.top - ins.bottom;
        
        if (intW > intWAllowed)
        {
            // ok, just resizing
            MySystem.s_printOutTrace(this, strMethod, "intW > intWAllowed, intW=" + intW + ", intWAllowed=" + intWAllowed + ", resizing");
            intW = intWAllowed;
        }
        
        if (intH > intHAllowed)
        {
            // ok, just resizing
            MySystem.s_printOutTrace(this, strMethod, "intH > intHAllowed, intH=" + intH + ", intHAllowed=" + intHAllowed + ", resizing");
            intH = intHAllowed;
        }
        
        viewerWidth = intW;
		viewerHeight = intH;
    }

    /**
     * Returns the viewer's Size. 
     * The form of the size is "width,height". 
     * @see setViewerSize
     */
    public String getViewerSize()
    {
	    MySecondaryView view;
	    String retval;
	    
	    if (viewerWidth != 0) 
	    {
	        retval = Integer.toString(viewerWidth) + "," +
		    Integer.toString(viewerHeight);
	    } 
	    
	    else 
	    {
	        // 
	        retval = "200,200";
	    }

	    // try to return the acutal viewer locations if it exists
	    switch (viewerStyle) 
	    {
	        case 0:
	            view = (MySecondaryView)_s_hstSecondaryWins.get(viewerName);
	            
	            if (view != null && view.frame.isVisible()) 
	            {
		            retval = Integer.toString(view.frame.getSize().width) + "," +
		                Integer.toString(view.frame.getSize().height);
	            }
	            
	            break;
	        
	        case 1:
	            if (_s_popupView != null && _s_popupView.popup.isVisible()) 
	            {
		            retval = Integer.toString(_s_popupView.popup.getSize().width) + "," +
		                Integer.toString(_s_popupView.popup.getSize().height);
	            }
	            
	            break;
	    }
	    
	    return retval;
    }

    /**
     * Sets the icon in the activator by url or id. The url is relative to the
     * base address of the document.
     * @see getIcon
     */
    public void setIconByName(String strName)
    {
        String strMethod = "setIconByName(strName)";
        
        if (strName == null)
            MySystem.s_printOutExit(this, strMethod, "nil strName");
        
	    ImageIcon ig = null;
	    URL url=null;
	    
	    // try to get it from the base address
	    try 
	    {
	        url = new URL (_base, strName); 
	    } 
	    
	    catch (java.net.MalformedURLException excMalformedURL) 
	    {
	        excMalformedURL.printStackTrace();
	        MySystem.s_printOutWarning(this, strMethod, "excMalformedURL caught, strName=" + strName + ", ignoring");
	        return;
	    }

	    // Valid URLs try the Icon
	    ig = new ImageIcon(url);
	    
	    if (ig != null) 
	    {
	        setIcon(ig);
	        // if the text is the default text then make it blank
	        String text = getText();
	        
	        if (text.compareTo(">") == 0) 
	        {
		        setText("");
	        }
	    }
	    
	    else
	    {
	        MySystem.s_printOutWarning(this, strMethod, "nil ig, strName=" + strName + ", ignoring");
	    }
    }

    /**
     * Sets the icon in the activator by id. 
     * @see getIcon
     */
    public void setIconByID(String strName)
    {
        String strMethod = "setIconByID(strName)";
        
        if (strName == null)
            MySystem.s_printOutExit(this, strMethod, "nil strName");
        
	    ImageIcon ig = null;
	    URL url=null;

	    Map map = _hs.getCombinedMap();
	    
	    try 
	    {
	        url = map.getURLFromID(ID.create(strName, _hs)); 
	    } 
	    
	    catch (java.net.MalformedURLException excMalformedURL) 
	    {
	        excMalformedURL.printStackTrace();
	        MySystem.s_printOutWarning(this, strMethod, "excMalformedURL caught, strName=" + strName + ", ignoring");
	        return;
	    }

	    // Valid URLs try the Icon
	    ig = new ImageIcon(url);
	    
	    if (ig != null) 
	    {
	        setIcon(ig);
	        // if the text is the default text then make it blank
	        String text = getText();
	        
	        if (text.compareTo(">") == 0) 
	        {
		        setText("");
	        }
	    }
	    
	    else
	    {
	         MySystem.s_printOutWarning(this, strMethod, "nil ig, strName=" + strName + ", ignoring");
	    }
    }

    /**
     * Sets the text Font family for the activator text.
     * For JDK 1.1 this must a family name of Dialog, DialogInput, Monospaced, 
     * Serif, SansSerif, or Symbol.
     */
    public void setTextFontFamily(String strFamily) 
    {
        String strMethod = "setTextFontFamily(strFamily)";
        
        if (strFamily == null)
            MySystem.s_printOutExit(this, strMethod, "nil strFamily");
            
        if (_textAttribs == null)
            MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
        
	    _textAttribs.removeAttribute(StyleConstants.FontFamily);
	    _textAttribs.addAttribute(StyleConstants.FontFamily, strFamily);
	    setFont(_getAttributeSetFont(_textAttribs));
	    //Font font = getFont();
    }

    /**
     * Returns the text Font family name of the activator text
     */
    public String getTextFontFamily()
    {
        String strMethod = "getTextFontFamily()";
        
        if (_textAttribs == null)
            MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
            
	    return StyleConstants.getFontFamily(_textAttribs);
    }

    /**
     * Sets the text size for the activator text.
     * The String size is a valid Cascading Style Sheet value for
     * text size. Acceptable values are as follows:
     * <ul>
     * <li>xx-small
     * <li>x-small
     * <li>small
     * <li>medium
     * <li>large
     * <li>x-large
     * <li>xx-large
     * <li>bigger - increase the current base font size by 1
     * <li>smaller - decrease the current base font size by 1
     * <li>xxpt - set the font size to a specific pt value of "xx"
     * <li>+x - increase the current base font size by a value of "x"
     * <li>-x - decrease the current base font size by a value of "x"
     * <li>x - set the font size to the point size associated with 
     * the index "x"
     * </ul>
     */
    public void setTextFontSize(String strSize)
    {
        String strMethod = "setTextFontSize(strSize)";
        
        if (strSize == null)
            MySystem.s_printOutExit(this, strMethod, "nil strSize");
        
	    int newsize, tmp;
	    
	    StyleSheet css = _doc.getStyleSheet();
	    
	    try
	    {
	        if (strSize.equals("xx-small"))
	        {
		        newsize = (int)css.getPointSize(0);
	        } 
	        
	        else if (strSize.equals("x-small")) 
	        {
		        newsize = (int)css.getPointSize(1);
	        } 
	        
	        else if (strSize.equals("small")) 
	        {
		        newsize = (int)css.getPointSize(2);
	        } 
	        
	        else if (strSize.equals("medium")) 
	        {
		        newsize = (int)css.getPointSize(3);
	        } 
	        
	        else if (strSize.equals("large")) 
	        {
		        newsize = (int)css.getPointSize(4);
	        } 
	        
	        else if (strSize.equals("x-large")) 
	        {
		        newsize = (int)css.getPointSize(5);
	        } 
	        
	        else if (strSize.equals("xx-large")) 
	        {
		        newsize = (int)css.getPointSize(6);
	        } 
	        
	        else if (strSize.equals("bigger")) 
	        {
		        newsize = (int)css.getPointSize("+1");
	        } 
	        
	        else if (strSize.equals("smaller")) 
	        {
		        newsize = (int)css.getPointSize("-1");
	        } 
	        
	        else if (strSize.endsWith("pt")) 
	        {
		        String sz = strSize.substring(0, strSize.length() - 2);
		        newsize = Integer.parseInt(sz);
	        } 
	        
	        else 
	        {
		        newsize = (int) css.getPointSize(strSize);
	        }
	    } 
	    
	    catch (NumberFormatException excNumberFormat) 
	    {
	        excNumberFormat.printStackTrace();
	        MySystem.s_printOutWarning(this, strMethod, "excNumberFormat caught, strSize=" + strSize + ", ignoring");
	        return;
	    }
	    
	    if (newsize == 0) 
	    {
	        MySystem.s_printOutWarning(this, strMethod, "newsize == 0, strSize=" + strSize + ", ignoring");
	        return;
	    }
	    
	    _textAttribs.removeAttribute(StyleConstants.FontSize);
	    _textAttribs.addAttribute(StyleConstants.FontSize, new Integer(newsize));
	    setFont(_getAttributeSetFont(_textAttribs));
	    //Font font = getFont();
    }

    /**
     * Returns the text Font family name of the activator text
     */
    public String getTextFontSize()
    {
        String strMethod = "getTextFontSize()";
        
        if (_textAttribs == null)
            MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
        
	    return Integer.toString(StyleConstants.getFontSize(_textAttribs));
    }

    /**
     * Sets the text Font Weigth for the activator text.
     * Valid weights are
     * <ul>
     * <li>plain
     * <li>bold
     * </ul>
     */
    public void setTextFontWeight(String strWeight) 
    {
        String strMethod = "setTextFontWeight(strWeight)";
        
        if (strWeight == null)
            MySystem.s_printOutExit(this, strMethod, "nil strWeight");
        
	    boolean isBold = false;
	    
	    if (strWeight.compareTo("bold") == 0) 
	    {
	        isBold = true;
	    } 
	    
	    else 
	    {
	        isBold = false;
	    }
	    
	    if (_textAttribs == null)
	        MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
	    
	    _textAttribs.removeAttribute(StyleConstants.Bold);
	    _textAttribs.addAttribute(StyleConstants.Bold, new Boolean(isBold));
	    setFont(_getAttributeSetFont(_textAttribs));
	    //Font font = getFont();
    }

    /**
     * Returns the text Font weight of the activator text
     */
    public String getTextFontWeight() 
    {
        String strMethod = "getTextFontWeight()";
        
        if (_textAttribs == null)
	        MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
        
	    if (StyleConstants.isBold(_textAttribs)) 
	    {
	        return "bold";
	    }
	    
	    return "plain";
    }

    /**
     * Sets the text Font Style for the activator text.
     * Valid font styles are
     * <ul>
     * <li>plain
     * <li>italic
     * </ul>
     */
    public void setTextFontStyle(String strStyle)
    {
        String strMethod = "setTextFontStyle(strStyle)";
        
        if (strStyle == null)
            MySystem.s_printOutExit(this, strMethod, "nil strStyle");
        
	    boolean isItalic=false;
	    
	    if (strStyle.compareTo("italic") == 0) 
	    {
	        isItalic = true;
	    } 
	    
	    else 
	    {
	        isItalic = false;
	    }
	    
	    if (_textAttribs == null)
            MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
	    
	    _textAttribs.removeAttribute(StyleConstants.Italic);
	    _textAttribs.addAttribute(StyleConstants.Italic, new Boolean(isItalic));
	    setFont(_getAttributeSetFont(_textAttribs));
	    //Font font = getFont();
    }

    /**
     * Returns the text Font style of the activator text
     */
    public String getTextFontStyle()
    {
        String strMethod = "setTextFontStyle(strStyle)";
        
        if (_textAttribs == null)
            MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
        
	    if (StyleConstants.isItalic(_textAttribs)) 
	    {
	        return "italic";
	    }
	    
	    return "plain";
    }

    /**
     * Sets the text Color for the activator text.
     * The following is a list of supported Color names
     * <ul>
     * <li>black
     * <li>blue
     * <li>cyan
     * <li>darkGray
     * <li>gray
     * <li>green
     * <li>lightGray
     * <li>magenta
     * <li>orange
     * <li>pink
     * <li>red
     * <li>white
     * <li>yellow
     * </ul>
     */
    public void setTextColor(String name)
    {
        String strMethod = "setTextColor(name)";
        
        if (name == null)
            MySystem.s_printOutExit(this, strMethod, "nil name");
        
	    Color color=null;
	    if (name.compareTo("black") == 0) {
	        color = Color.black;
	    } else if (name.compareTo("blue") == 0) {
	        color = Color.blue;
	    } else if (name.compareTo("cyan") == 0) {
	        color = Color.cyan;
	    } else if (name.compareTo("darkGray") == 0) {
	        color = Color.darkGray;
	    } else if (name.compareTo("gray") == 0) {
	        color = Color.gray;
	    } else if (name.compareTo("green") == 0) {
	        color = Color.green;
	    } else if (name.compareTo("lightGray") == 0) {
	        color = Color.lightGray;
	    } else if (name.compareTo("magenta") == 0) {
	        color = Color.magenta;
	    } else if (name.compareTo("orange") == 0) {
	        color = Color.orange;
	    } else if (name.compareTo("pink") == 0) {
	        color = Color.pink;
	    } else if (name.compareTo("red") == 0) {
	        color = Color.red;
	    } else if (name.compareTo("white") == 0) {
	        color = Color.white;
	    } else if (name.compareTo("yellow") == 0) {
	        color = Color.yellow;
	    }

	    if (color == null)
	    {
	        MySystem.s_printOutWarning(this, strMethod, "nil color, name=" + name + ", ignoring");
	        return;
	    }
	    
	    if (_textAttribs == null)
	        MySystem.s_printOutExit(this, strMethod, "nil _textAttribs");
	    
	    _textAttribs.removeAttribute(StyleConstants.Foreground);
	    _textAttribs.addAttribute(StyleConstants.Foreground, color);
	    setForeground(color);
    }

    /**
     * Returns the text Color of the activator text
     */
    public String getTextColor()
    {
        // OK can redirect to subclass
	    return super.getTextColor();
    }


    public void propertyChange(PropertyChangeEvent evtPropertyChange)
    {
        String strMethod = "propertyChange(evtPropertyChange)";
        
	    String strNameProp = evtPropertyChange.getPropertyName();
	    
	    MySystem.s_printOutTrace(this, strMethod, "..., strNameProp=" + strNameProp);
	    
	    if (strNameProp.equals("page")) 
	    {
	        String title;
	        
	        switch (viewerStyle) 
	        {
	            case 0:
		            MySecondaryView view =
		                (MySecondaryView) _s_hstSecondaryWins.get(viewerName);
		        
		            if (view.jheditor != null) 
		            {
		                title = view.jheditor.getDocumentTitle();
		            } 
		        
		            else 
		            {
		                Document doc = view.editor.getDocument();
		                title = (String)doc.getProperty(Document.TitleProperty);
		            }
		        
		            if (title == null) 
		            {
		                title = "";
		            }
		        
		            view.frame.setTitle(title);
	         }
	    }
    }

   

    /**
     * Displays the viewer according to the viewerType
     */
    public void actionPerformed(ActionEvent evtAction)
    {
        final String f_strMethodMain = "actionPerformed(evtAction)";
        
        
        
        
	    JFrame frmSub = null;
	    JEditorPane editor= null;
	    JHelpContentViewer jheditor=null;
	    JPopupMenu popup = null;

	    //	System.err.println("clicked on me...");
	    switch (viewerStyle) 
	    {
	        case 0:
	            MySecondaryView view = 
		            (MySecondaryView) _s_hstSecondaryWins.get(viewerName);
	            
	            if (view == null) 
	            {
	                JFrame frmOwner = JH2Abs._s_getFrameOwnerHelpSet_(this);
            
                    if (frmOwner == null)
                        MySystem.s_printOutExit(this, f_strMethodMain, "nil frmOwner");

		            frmSub = new JFrame();
		            
		            if (frmOwner.getIconImage() != null)
		                frmSub.setIconImage(frmOwner.getIconImage());       
		            
		            WindowListener l = new WindowAdapter() 
		            {
		                String strMethodSub1 = f_strMethodMain + "." + "WindowAdapter()";
		                
		                public void windowClosing(WindowEvent evtWindow)
		                {
		                    
		                    _removeView(evtWindow.getWindow());
		                }
		                
		                
		                public void windowClosed(WindowEvent evtWindow) 
		                {
		                    _removeView(evtWindow.getWindow());
		                }
		            };
		
		            frmSub.addWindowListener(l);

		            if (_hs != null) 
		            {
		                jheditor = new JHelpContentViewer(_hs);
		                jheditor.addPropertyChangeListener(this);
		                frmSub.getContentPane().add(jheditor);
		            } 
		            
		            else 
		            {
		                editor = new JEditorPane();
		                editor.setEditable(false);
		                editor.addPropertyChangeListener(this);
		                frmSub.getContentPane().add(editor);
		            }
		            
		            frmSub.pack();
		            
		            view = new MySecondaryView(frmSub, null, editor,
					    jheditor, viewerName);
		            
		            _s_hstSecondaryWins.put(viewerName, view);
	            }
	        
	            _setPage(view);
	        
	            if (viewerX != -1) 
	            {
		            view.frame.setLocation(viewerX, viewerY);
	            }
    	        
	            // By default the frameSize is 200,200
	            Dimension frameSize = new Dimension(_f_s_intSizeMin, _f_s_intSizeMin);
    	        
	            if (viewerWidth != 0) 
	            {
		            frameSize.setSize(viewerWidth, viewerHeight); 
	            }
    	        
	            view.frame.setSize(frameSize);
	            
	            // -- 
	            if (view.frame.getState() == Frame.ICONIFIED)
	            {
	                view.frame.setState(Frame.NORMAL);
	            }
	            // --
	            
	            
	            view.frame.setVisible(true);
	            view.frame.toFront();
	            
	            
	            break;
	    
	        case 1:
	            if (_s_popupView == null) 
	            {
		            popup = new JPopupMenu();
		            popup.setLayout (new BoxLayout(popup, BoxLayout.Y_AXIS));
		            popup.setBorderPainted (true);
		            popup.setBorder (BorderFactory.createLineBorder(Color.black));
		            popup.setOpaque(false);
		            popup.setDoubleBuffered(true);
    		        
		            popup.registerKeyboardAction(
		                new AbstractAction() 
			            { 
			                public void actionPerformed(ActionEvent ae) 
			                {
						        hidePopup();
					        }
					    },
					
					KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
					JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		        
		            if (_hs != null) 
		            {
		                jheditor = new JHelpContentViewer(_hs);
		                jheditor.addPropertyChangeListener(this);
		                popup.add(jheditor);
		            } 
		        
		            else 
		            {
		                editor = new JEditorPane();
		                editor.setEditable(false);
		                editor.addPropertyChangeListener(this);
		                popup.add(editor);
		            }
		        
		            _s_popupView = new MySecondaryView(null, popup, editor,
			            jheditor, null);
	            }
            
                // hold invoker of popup window if this JHSecondaryViewer has been 
                // already in popup window, bug #4463602
                if (SwingUtilities.getAncestorOfClass(JPopupMenu.class, this) != _s_popupView.popup) 
                {
                    _s_popupView.popup.setInvoker(this);
                }
	        
	            _setPage(_s_popupView);
	            _showPopup();
	            break;
	        
	        default:
	            System.out.println ("Unknown viewerStyle");
	    }
    }

    


    /**
     * hide the popup
     */
    public void hidePopup()
    {
        String strMethod = "hidePopup()";
        
        if (_s_popupView == null)
            MySystem.s_printOutExit(this, strMethod, "nil _s_popupView");
        
	    _s_popupView.popup.setVisible(false);
	    
	    if (_s_container == null)
            MySystem.s_printOutExit(this, strMethod, "nil _s_container");
	    
        _s_container.repaint();
    }
    
    // ---------
    // PROTECTED

    /**
        !!!!!!!!!!!!!!!! maybe can just redirect to subclass !!!!!!!!!!!!!!!!!!!!!!
    **/
    protected Rectangle computePopupBounds(Dimension popupSize)
    {	    
	    // Note all Points in computePopupBounds are either relative to
	    // the screen. The desired boundry must fit on the screen. If it is
	    // in a Modal Dialg it has to fit within the dialog

        Rectangle absBounds;
	    Point p;

	    // Calculate the absolute boundry. Modal Dialogs must be within the 
	    // Dialog.
        boolean inModalDialog = _inModalDialog();
        
        /** Workaround for modal dialogs. See also JPopupMenu.java **/
        if ( inModalDialog ) 
        {
            Dialog dlg = _getDialog();
            
            if ( dlg instanceof JDialog ) 
            {
                JRootPane rp = ((JDialog)dlg).getRootPane();
                p = rp.getLocationOnScreen();
                absBounds = rp.getBounds();
                absBounds.x = p.x;
                absBounds.y = p.y;
            } else {
                absBounds = dlg.getBounds();
	    }
        } else {
            Dimension scrSize = Toolkit.getDefaultToolkit().getScreenSize();
            absBounds = new Rectangle(0, 0, scrSize.width, scrSize.height);
        }

	// Get a rectangle below and to the right and see if it fits
	p = new Point(0, this.getBounds().height);
	SwingUtilities.convertPointToScreen(p, this);
        Rectangle br = new Rectangle(p.x, p.y, 
				     popupSize.width, popupSize.height);
        if ( SwingUtilities.isRectangleContainingRectangle(absBounds, br) ) {
	    // below and to the right fits return the rectangle
            return br;
        }

	// below and right failed - try to adjust the right side to fit
	Rectangle bradjust = new Rectangle(br);
	bradjust.setLocation(br.x - ((br.x + br.width)- absBounds.width), 
			     br.y);
	if ( SwingUtilities.isRectangleContainingRectangle(absBounds, 
							   bradjust) ) {
	    // below and to the right fits return the rectangle
            return bradjust;
	} 

	// below and right adjust failed - try above right
	Rectangle ar = new Rectangle(br.x, 
				     br.y-(br.height+this.getBounds().height),
				     br.width, br.height);
	if (SwingUtilities.isRectangleContainingRectangle(absBounds, ar)) {
	    // above and to the right fits return the rectangle
            return ar;
	} 

	// above and right failed - adjust the right side to fit
	Rectangle aradjust = new Rectangle(ar);
	aradjust.setLocation(ar.x - ((ar.x + ar.width) - absBounds.width), 
			     aradjust.y);
	if ( SwingUtilities.isRectangleContainingRectangle(absBounds, 
							   aradjust) ) {
	    // below and to the right fits return the rectangle
            return aradjust;
	} 

	// above and right adjust failed - try left below
	p = new Point(this.getBounds().width, 0);
	SwingUtilities.convertPointToScreen(p, this);
	Rectangle lb = new Rectangle(p.x, p.y, 
				     popupSize.width, popupSize.height);
	if (SwingUtilities.isRectangleContainingRectangle(absBounds, lb)) {
	    // left and below fits return the rectangle
            return lb;
	} 

	// left and below failed - adjust the top side to fit
	Rectangle lbadjust = new Rectangle(lb);
	lbadjust.setLocation(lbadjust.x,
			     lb.y - ((lb.y + lb.height) - absBounds.height)); 
	if ( SwingUtilities.isRectangleContainingRectangle(absBounds,
							   lbadjust) ) {
	    // left and below adjusted fits return the rectangle
            return lbadjust;
	} 

	// left and below adjust failed - try right and below
	Rectangle rb = new Rectangle(lb.x-(lb.width+this.getBounds().width), 
				     lb.y,
				     lb.width, lb.height);
	if (SwingUtilities.isRectangleContainingRectangle(absBounds, rb)) {
	    // right and below fits return the rectangle
            return rb;
	} 

	// right and below failed - adjust the top side to fit
	Rectangle rbadjust = new Rectangle(rb);
	rbadjust.setLocation(rbadjust.x,
			     rb.y - ((rb.y + rb.height) - absBounds.height)); 
	if ( SwingUtilities.isRectangleContainingRectangle(absBounds, 
							   rbadjust) ) {
	    // right and below fits return the rectangle
            return rbadjust;
	} 

	// Bummer - tried all around the object so no try covering it up
	// Nothing fancy here upper left corner
	Rectangle cover = new Rectangle(0, 0, 
					popupSize.width, 
					popupSize.height);
	if (SwingUtilities.isRectangleContainingRectangle(absBounds, cover)) {
	    // covering up the object fits return the rectangle
            return cover;
	} 

	// Humm. The desired size is just to large. Shrink to fit.
	SwingUtilities.computeIntersection(absBounds.x,
					   absBounds.y,
					   absBounds.width,
					   absBounds.height,
					   cover);
	return cover;
    }

    // -------
    // PRIVATE
    
    
    
    /*
        properties
    */
    
    private int viewerWidth = 0; 
    private int viewerHeight = 0; 
    private int viewerStyle = 0;
    private String viewerName = ""; 
    private int viewerX = 0; 
    private int viewerY = 0; 
    private Map.ID ident;
    private String content = ""; 
    private int viewerActivator = 0;
    
    
    // --
    
    
    private HelpSet _hs;
    private URL _base;
    private View _myView;
    private HTMLDocument _doc;
    private SimpleAttributeSet _textAttribs;
    
    private Cursor _crsOrigCursor;
    
    
    /**
     * Set the page to be displayed
     */
    private void _setPage(MySecondaryView view) 
    {
        String strMethod = "_setPage(view)";
        
        if (view == null)
            MySystem.s_printOutExit(this, strMethod, "nil view");
        
	    String title = "";
	    
	    if (ident != null) 
	    {
	        if (view.jheditor != null) 
	        {
		        try 
		        {
		            view.jheditor.setCurrentID(ident);
		        } 
		        
		        catch (Exception exc) 
		        {
		            // !!!!
		            exc.printStackTrace();
		            MySystem.s_printOutWarning(this, strMethod, "exc caught, ignoring");
		        }
	        } 
	        
	        else 
	        {
		        Map map = _hs.getCombinedMap();
		        
		        try 
		        {
		            URL url = map.getURLFromID(ident);
		            view.editor.setPage(url);
		        } 
		        
		        catch (Exception exc) 
		        {
		            // !!!!
		            exc.printStackTrace();
		            MySystem.s_printOutWarning(this, strMethod, "exc caught, ignoring");
		        }
	        }
	    } 
	    
	    else if (content != "") 
	    {
	        URL url = null;
	        
	        try 
	        {
		        url = new URL(_base, content);
		        
		        if (view.jheditor != null) 
		        {
		            view.jheditor.setCurrentURL(url);
		        } 
		        
		        else 
		        {
		            view.editor.setPage(url);
		            Document doc = view.editor.getDocument();
		        }
	        } 
	        
	        catch (Exception exc) 
	        {
		        // !!!!
		        exc.printStackTrace();
		        MySystem.s_printOutWarning(this, strMethod, "exc caught, ignoring");
	        }
	    }
    }
    
 
    private void _removeView(Window win) 
    {
        String strMethod = "_removeView(win)";
                
        
        if (win == null)
            MySystem.s_printOutExit(this, strMethod, "nil win");
        
	    if (win instanceof JFrame) 
	    {
	        JFrame frmSub = (JFrame) win;
	        Enumeration views = _s_hstSecondaryWins.elements();
	        
	        while (views.hasMoreElements()) 
	        {
		        MySecondaryView view = (MySecondaryView) views.nextElement();
		        
		        if (view.frame == frmSub) 
		        {
		            MySystem.s_printOutTrace(this, strMethod, "view.frame == frmSub");
		            
		            
		            /*
		            // this is the element to remove
		            view.editor = null;
		            view.jheditor = null;
		            */
		            
		            _s_hstSecondaryWins.remove(view.name);
		            
		            view.destroy();
		            view = null;
		            
		            System.gc();
		            
		            //break;
		            return;
		        }
		        
		        
	        }
	    }
    }
    
    
    /**
     * show the popup
     */
    private void _showPopup()
    {

        _s_popupView.popup.setLightWeightPopupEnabled(true);

        // invoker of popup window
        JHMySecondaryViewer invoker = this;
        
        if (_s_popupView.popup.getInvoker() instanceof JHMySecondaryViewer) 
        {
            invoker = (JHMySecondaryViewer)_s_popupView.popup.getInvoker();
        }

	    // for now the default size is 200,200
	    // I'd like to use the preferred size of the editor(s) but that
	    // isn't working correctly
        Dimension popupSize =  new Dimension((viewerWidth == 0) ? _f_s_intSizeMin : viewerWidth,
                                             (viewerHeight == 0) ? _f_s_intSizeMin : viewerHeight);

        Rectangle popupBounds = invoker.computePopupBounds(popupSize);

	    // set the preferred size on popup so it will change size
	    _s_popupView.popup.setPreferredSize(popupBounds.getSize());
	    Point point = popupBounds.getLocation();
	    SwingUtilities.convertPointFromScreen(point, invoker);
        _s_popupView.popup.setVisible(false);
        _s_popupView.popup.show(invoker, point.x, point.y);
	    
	    if (_s_popupView.jheditor != null) 
	    {
	        _s_popupView.jheditor.requestFocus();
	    } 
	    
	    else 
	    {
	        _s_popupView.editor.requestFocus();
	    }
    }
    
    
    /**
     * Creates a link button. This is just a JButton with default settings.
     */
    private void _createLinkButton()
    {
	    LookAndFeel.installBorder(this, _f_s_strButtonPropertyPrefix + "border");
	    setBorderPainted(true);
	    setFocusPainted(true);
	    setAlignmentY(Container.CENTER_ALIGNMENT);
	    setContentAreaFilled(true);
	    setBackground(UIManager.getColor(_f_s_strButtonPropertyPrefix + "background"));
	    
	    if (_textAttribs != null && _textAttribs.isDefined(StyleConstants.Foreground)) 
	    {
	        setForeground((Color)_textAttribs.getAttribute(StyleConstants.Foreground));
	    } 
	    
	    else 
	    {
	        setForeground(UIManager.getColor(_f_s_strButtonPropertyPrefix + "foreground"));
	    }
	    
	    invalidate();
    }
    
    /**
     * Creates a link label. A link label is a form of a JButton but without a
     * button like appearance.
     */
    private void _createLinkLabel() 
    {
	    setBorder(new EmptyBorder(1,1,1,1));
	    setBorderPainted(false);
	    setFocusPainted(false);
	    setAlignmentY(_getPreferredLabelAlignment());
    	setContentAreaFilled(false);
	    setBackground(UIManager.getColor(_f_s_strEditorPropertyPrefix + "background"));
	    
	    if (_textAttribs != null && _textAttribs.isDefined(StyleConstants.Foreground)) 
	    {
	        setForeground((Color)_textAttribs.getAttribute(StyleConstants.Foreground));
    	} 
    	
    	else 
    	{
	        setForeground(Color.blue);
	    }
	    
	    invalidate();
    }
    
    /**
     * Determine the alignment offset so the text is aligned with other views
     * correctly.
     */
    private float _getPreferredLabelAlignment() 
    {
        Icon icon = (Icon)getIcon();
        String text = getText();

        Font font = getFont();
        
        //  deprecated
        //FontMetrics fms = getToolkit().getFontMetrics(font);
        FontMetrics fms = getFontMetrics(font);
          
          
        Rectangle iconR = new Rectangle();
        Rectangle textR = new Rectangle();
        Rectangle viewR = new Rectangle(Short.MAX_VALUE, Short.MAX_VALUE);

        SwingUtilities.layoutCompoundLabel(
            this, fms, text, icon,
            getVerticalAlignment(), getHorizontalAlignment(),
            getVerticalTextPosition(), getHorizontalTextPosition(),
            viewR, iconR, textR,
	    (text == null ? 0 : ((BasicButtonUI)ui).getDefaultTextIconGap(this))
        );

        /* The preferred size of the button is the size of 
         * the text and icon rectangles plus the buttons insets.
         */
        Rectangle r = iconR.union(textR);

        Insets insets = getInsets();
        r.height += insets.top + insets.bottom;

        /* Ensure that the height of the button is odd,
         * to allow for the focus line.
         */
        if(r.height % 2 == 0) 
        { 
	        r.height += 1;
	    }

	    float offAmt = fms.getMaxAscent() + insets.top;
	    return offAmt/(float)r.height;
    }
    
    /**
     * Gets the font from an attribute set.  This is
     * implemented to try and fetch a cached font
     * for the given AttributeSet, and if that fails 
     * the font features are resolved and the
     * font is fetched from the low-level font cache.
     * Font's are cached in the StyleSheet of a document
     *
     * @param attr the attribute set
     * @return the font
     */
    private Font _getAttributeSetFont(AttributeSet attr) 
    {
        String strMethod = "_getAttributeSetFont(attr)";
        
        if (attr == null)
            MySystem.s_printOutExit(this, strMethod, "nil attr");
        
        // PENDING(prinz) add cache behavior
        int style = Font.PLAIN;
        
        if (StyleConstants.isBold(attr)) 
        {
            style |= Font.BOLD;
        }
        
        if (StyleConstants.isItalic(attr)) 
        {
            style |= Font.ITALIC;
        }
        
        String strFamily = StyleConstants.getFontFamily(attr);
        int size = StyleConstants.getFontSize(attr);

	    /**
	    * if either superscript or subscript is
	    * is set, we need to reduce the font size
	    * by 2.
	    */
	    if (StyleConstants.isSuperscript(attr) || StyleConstants.isSubscript(attr)) 
	    {
	        size -= 2;
	    }

	    // fonts are cached in the StyleSheet so use that
        return _doc.getStyleSheet().getFont(strFamily, style, size);
    }
    
    private Dialog _getDialog() 
    {
        String strMethod = "_getDialog()";
        
        Container parent;
        
        if (_s_container == null)
            MySystem.s_printOutExit(this, strMethod, "nil _s_container");
        
        for ( parent = _s_container.getParent() ; parent != null && !(parent instanceof Dialog)
            && !(parent instanceof Window) ; parent = parent.getParent() );
        
        if ( parent instanceof Dialog )
            return (Dialog) parent;
        else
            return null;
    }

    private boolean _inModalDialog() 
    {
        return (_getDialog() != null);
    }
}
