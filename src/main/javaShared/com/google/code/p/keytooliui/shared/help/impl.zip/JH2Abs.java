/*
 *
 * Copyright (c) 2001-2003 XLReader Project.
 * All Rights Reserved.
 * http://www.xlreader.com
 *
 * This software is the confidential and proprietary information of XLReader Project.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of XLReader Project's license agreement.
 *
 * THE SOFTWARE IS PROVIDED AND LICENSED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * LICENSE FOR THE SOFTWARE DOES NOT INCLUDE ANY CONSIDERATION FOR ASSUMPTION OF RISK
 * BY XLREADER PROJECT, AND XLREADER PROJECT DISCLAIMS ANY AND ALL LIABILITY FOR INCIDENTAL
 * OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF OR INABILITY
 * TO USE THE SOFTWARE, EVEN IF XLREADER PROJECT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
 *
 */

package com.xlreader.shared.help.impl;

/**
    known subclasses:
    . JH2SecondaryViewer ==> rewritten JHSecondaryViewer
    . JH2Browser ==> open up user's browser
    . JH2SwAbs ==> abstract class for secondary windows
       eg, subclasses: 
       . Text/HTML, 
       . Text/RTF, 
       . Media/Audio, 
       . Media/Video, 
       . RTP/Audio, 
       . RTP/VideoOnly, 
       . RTP/VideoAudio.
**/

import com.sun.java.help.impl.*;


import javax.swing.*;

import java.awt.*;

abstract public class JH2Abs extends JHSecondaryViewer
{
    // ----------------
    // STATIC PROTECTED
    
    static protected JFrame _s_getFrameOwnerHelpSet_(Component cmp)
    {
        while (cmp != null)
	    {        
	        if (cmp instanceof JFrame) 
	            return (JFrame) cmp;
        	        
	        cmp = cmp.getParent();
	    }
	            
        return null;
    }
    
    // ---------
    // PROTECTED
    
    protected JH2Abs()
    {
    }
}