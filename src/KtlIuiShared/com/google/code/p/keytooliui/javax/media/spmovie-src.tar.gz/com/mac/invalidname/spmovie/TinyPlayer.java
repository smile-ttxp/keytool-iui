/*
  TinyPlayer.java - (c) 2002 Chris Adamson, invalidname@mac.com
  http://homepage.mac.com/invalidname/spmovie/
  This source is released under terms of the GNU Public License
  http://www.gnu.org/licenses/gpl.html
*/

package com.mac.invalidname.spmovie;

import java.awt.*;
import java.awt.event.*;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.media.*;
import javax.media.protocol.*;
import java.net.URL;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

/** A very simple Frame that demonstrates the JarEntryDataSource,
    assuming that <code>movie/themovie.mov</code> or
    <code>movie/themovie.avi</code> can be found along the
    classpath (ie, inside the jar)
    <p>
    This class also provides a "JMF Readme" menu item that 
    makes distribution of self-playing media legal under terms
    of Sun's JMF license, which allows for removal of items
    that the jmfcustomizer doesn't pick up, but requires that the
    readme always be available.
 */
public class TinyPlayer extends Frame
    implements ActionListener {

    public static final String QT_MOVIE_NAME = "movie/themovie.mov";
    public static final String AVI_MOVIE_NAME = "movie/themovie.avi";
    public static final String JMF_README_PATH =
        "misc/JMF2.1.1/doc/readme.html";
    protected MenuItem quitItem;
    protected MenuItem aboutSPMovieItem;
    protected MenuItem aboutJMFReadmeItem;

    public TinyPlayer (String title) {
        super(title);
        setLayout (new BorderLayout());
        try {
            Player p = setUpPlayer();
            // System.out.println ("Got Player: " + p);
            Component vc = p.getVisualComponent();
            Component c = p.getControlPanelComponent();
            add (vc, BorderLayout.CENTER);
            add (c, BorderLayout.SOUTH);
            setUpMenus();
            // shut down when window closed
            addWindowListener (new WindowAdapter() {
                    public void windowClosing (WindowEvent we) {
                        quit();
                    }
                });
        } catch (Exception e) {
            removeAll();
            e.printStackTrace();
            add (new Label ("Can't load movie: " + e.toString()));
        }
    }

    protected Player setUpPlayer()
        throws IOException, NoPlayerException,
               CannotRealizeException, NoDataSourceException,
               FileNotFoundException {
        // find movie url from classpath
        URL movieURL =
            this.getClass().getClassLoader().getResource(QT_MOVIE_NAME);
        if (movieURL == null)
            movieURL =
                this.getClass().getClassLoader().getResource(AVI_MOVIE_NAME);
        if (movieURL == null)
            throw new FileNotFoundException (
                      "Didn't find movie/themovie.mov " +
                      "or movie/themovie.avi");
        // System.out.println ("Found movie " + movieURL.toString());
        // get a Player for it
        MediaLocator ml = new MediaLocator (movieURL);
        DataSource ds = null;
        if (movieURL.getProtocol().equals ("jar"))
            ds = new JarEntryDataSource (ml);
        else
            ds = Manager.createDataSource (ml);
        Player p = Manager.createRealizedPlayer (ds);
        return p;
    }

    protected void setUpMenus () {
        Menu fileMenu = new Menu ("File");
        quitItem = new MenuItem ("Quit");
        fileMenu.add (quitItem);
        quitItem.addActionListener (this);
        Menu aboutMenu = new Menu ("About");
        aboutSPMovieItem = new MenuItem ("Self-playing movie");
        aboutMenu.add (aboutSPMovieItem);
        aboutSPMovieItem.addActionListener (this);
        aboutJMFReadmeItem = new MenuItem ("JMF read-me");
        aboutMenu.add (aboutJMFReadmeItem);
        aboutJMFReadmeItem.addActionListener (this);
        MenuBar mb = new MenuBar();
        mb.add (fileMenu);
        mb.add (aboutMenu);
        this.setMenuBar (mb);
    }

    /** handles menu selections
     */
    public void actionPerformed (ActionEvent ae) {
        Object source = ae.getSource();
        if (source == quitItem)
            quit();
        else if (source == aboutSPMovieItem)
            showAbout();
        else if (source == aboutJMFReadmeItem)
            showJMFReadMe();
    }

    protected void showAbout() {
        // JOptionPane is kind of a cheat in this
        // otherwise AWT-only app
        JOptionPane.showMessageDialog (this,
                            "Self-playing JMF movie demonstration\n" +
                            "http://homepage.mac.com/invalidname/spmovie\n"+
                            "(c) 2002 Chris Adamson, invalidname@mac.com\n"+
                            "Released under terms of GNU public license\n",
                            "About self-playing movie",
                            JOptionPane.PLAIN_MESSAGE);           
    }

    protected void showJMFReadMe() {
        // uses the Swing JEditorPane to render HTML
        try {
            URL readmeURL =
                this.getClass().getClassLoader().getResource(JMF_README_PATH);
            if (readmeURL == null) 
                throw new FileNotFoundException();
            InputStream in = readmeURL.openStream();
            JEditorPane ed = new JEditorPane(readmeURL);
            // ed.setPreferredSize (new Dimension (400, 400));
            ed.setEditable (false);
            JScrollPane scroller =
                new JScrollPane (ed,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scroller.setPreferredSize (new Dimension (400, 400));
            final Dialog d = new Dialog (this, "README", true);
            d.setLayout (new BorderLayout());
            d.add (scroller, BorderLayout.CENTER);
            Button closeButton = new Button ("Close");
            closeButton.addActionListener (new ActionListener() {
                    public void actionPerformed (ActionEvent e) {
                        d.setVisible(false);
                        d.dispose();
                    }
                });
            d.add (closeButton, BorderLayout.SOUTH);
            d.pack();
            d.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog (this,
                                           "Can't get JMF README",
                                           "README",
                                           JOptionPane.ERROR_MESSAGE);
        }
    }

    protected void quit() {
        System.exit(0);
    }


    public static void main (String[] args) {
        TinyPlayer tp = new TinyPlayer ("TinyPlayer test");
        tp.pack();
        tp.setVisible(true);
    }

}
